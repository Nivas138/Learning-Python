from random import shuffle,randint,choice
from copy import copy
alphabet=range(0,26)

def shift(l, n): 
	return l[n:] + l[:n]
	
class cog: 
	def create(self):
		self.transformation=copy(alphabet)
		shuffle(self.transformation)
		return 
	def passthrough(self,i):
		return self.transformation[i]
	def passthroughrev(self,i):
		return self.transformation.index(i)
	def rotate(self):
		self.transformation=shift(self.transformation, 1)
	def setcog(self,a):
		self.transformation=a

class enigma: 	
	def __init__(self, nocogs,printspecialchars):
		self.printspecialchars=printspecialchars
		self.nocogs=nocogs
		self.cogs=[]
		self.oCogs=[] 
		
		for i in range(0,self.nocogs): 
			self.cogs.append(cog())
			self.cogs[i].create()
			self.oCogs.append(self.cogs[i].transformation)
		
		
		refabet=copy(alphabet)
		self.reflector=copy(alphabet)
		while len(refabet)>0:
			a=choice(refabet)
			refabet.remove(a)
			b=choice(refabet)
			refabet.remove(b)
			self.reflector[a]=b
			self.reflector[b]=a

	def print_setup(self):
		print ("Enigma Setup:\nCogs: ",self.nocogs,"\nCog arrangement:")
		for i in range(0,self.nocogs):
			print (self.cogs[i].transformation)
		print ("Reflector arrangement:\n",self.reflector,"\n")
		
	def reset(self):
		for i in range(0,self.nocogs):
			self.cogs[i].setcog(self.oCogs[i])
			
	def encode(self,text):
		ln=0
		ciphertext=""
		for l in text.lower():
			num=ord(l)%97
			if (num>25 or num<0):
				if (self.printspecialchars): 
					ciphertext+=l 
				else:
					pass 
			else:
				ln+=1
				for i in range(0,self.nocogs): 
					num=self.cogs[i].passthrough(num)
					
				num=self.reflector[num] 
				
				for i in range(0,self.nocogs): 
					num=self.cogs[self.nocogs-i-1].passthroughrev(num)
				ciphertext+=""+chr(97+num) 
				
				for i in range(0,self.nocogs): 
					if ( ln % ((i*6)+1) == 0 ): 
						self.cogs[i].rotate()
		return ciphertext

plaintext="""CRYPTOGRAPHY """

x=enigma(4,True)


print ("Plaintext:\n"+plaintext+"\n")
ciphertext=x.encode(plaintext)
print("Encryption")
print ("Ciphertext:\n"+ciphertext+"\n")


x.reset()
plaintext=x.encode(ciphertext)
print("Decryption")
print ("Plaintext:\n"+plaintext+"\n")
