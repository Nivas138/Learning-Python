def gen_random_bytes(k):
    i = 0
    j = 0
    while True:
        i = (i + 1) % 256
        j = (j + k[i]) % 256
        k[i], k[j] = k[j], k[i]
        yield k[(k[i] + k[j]) % 256]


def run_rc4(k, text):
    cipher_chars = []
    random_byte_gen = gen_random_bytes(k)
    i=0
    for char in text:
        byte = ord(char)
	gen_bytes[i]= random_byte_gen.next()
        print("random generate byte" +str(gen_bytes[i]))
	cipher_byte = byte ^ gen_bytes[i]
	i=i+1
        cipher_chars.append(chr(cipher_byte))
    return ''.join(cipher_chars)

def decrypt(ciphertext):
    i=0
    plain_chars=[]
    for char in ciphertext:
	byte=ord(char)
	plain_byte=byte ^ gen_bytes[i]
	i=i+1
	plain_chars.append(chr(plain_byte))
    return ''.join(plain_chars)	
	 
k=range(256)
for i in range(256):
    k[i]=i
print("enter the plaintext")
s=raw_input()
gen_bytes=range(len(s))
cipher=run_rc4(k,s)
print(cipher)
plain_text=decrypt(cipher)
print "After Decryption\nPlainText:" + str(plain_text)
