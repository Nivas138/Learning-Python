
def gcd(x,y):
    while y != 0:
        x, y = y, x % y
    return x

def primRoots(modulo):
    roots = []
    required_set = set(num for num in range (1, modulo) if gcd(num, modulo) == 1)

    for g in range(1, modulo):
        actual_set = set(pow(g, powers) % modulo for powers in range (1, modulo))
        if required_set == actual_set:
            roots.append(g)           
    
    return roots
    	
print("DIFFIE-HELLMANN ALGORITHM")
p=int(input("Enter a prime number(p): "))
q=int(input("Enter a number(q) (primitive root of p(1<q<p-1)): "))
primitive_roots=primRoots(p)
if q in primitive_roots:
	a=int(input("Enter the private key of A(a): "))
	b=int(input("Enter the private key of B(b): "))
	a=(q**a) % p
	b=(q**b) % p
	#secret_variables(a,b,p,q)
	print("Generated private key of A: "+str(a))
	print("Generated private key of B: "+str(b))
	#secret_key=decrypt(a,b,p)
	s1=(b**a) % p
	s2=(a**b) % p

	print("Generated secret keys of A&B: "+str(s1))

else:
	print("Entered q is not a primitive root")
	print(primitive_roots)
	print("Key exchanging got stopped")
