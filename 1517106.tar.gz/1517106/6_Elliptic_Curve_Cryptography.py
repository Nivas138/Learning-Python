
def encrypt_c1(k,p):
	c1=k*p
	return c1
def encrypt_c2(m,k,public_key):
	c2=m+k*public_key
	return c2
def decrypt(cipher_text2,cipher_text1,private_key):
	org_msg=cipher_text2-(private_key*cipher_text1)
	return org_msg

p=int(input("Enter a point of the curve(prime) :"))
n=int(input("Enter the value of n:"))

print("Enter a random number")
private_key=int(input())
print("The public key is:")
public_key=private_key*p
print(public_key)

print("Enter a message:")
m=int(input())
print("Enter the k value ")
k=int(input())
cipher_text1=encrypt_c1(k,p)
cipher_text2=encrypt_c2(m,k,public_key)
print("Cipher text:")
print(cipher_text1)
print(cipher_text2)

msg=decrypt(cipher_text2,cipher_text1,private_key)
print("Decrypted plain text: "+str(msg))

